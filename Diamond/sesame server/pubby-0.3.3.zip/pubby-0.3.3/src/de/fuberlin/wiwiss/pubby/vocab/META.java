package de.fuberlin.wiwiss.pubby.vocab;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;

public class META {

	public static final String NS = "http://example.org/metadata#";
	
	private static final Model m = ModelFactory.createDefaultModel();

}
